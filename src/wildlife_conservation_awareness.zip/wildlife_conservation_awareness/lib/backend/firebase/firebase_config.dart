import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBwViI39yCZPf7hQbR9DIsHv7cXCR5V6dA",
            authDomain: "wildlife-conservation-a-mvbq8z.firebaseapp.com",
            projectId: "wildlife-conservation-a-mvbq8z",
            storageBucket: "wildlife-conservation-a-mvbq8z.firebasestorage.app",
            messagingSenderId: "1031986447412",
            appId: "1:1031986447412:web:4d11864fbf233367943661"));
  } else {
    await Firebase.initializeApp();
  }
}
