import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'card_component_model.dart';
export 'card_component_model.dart';

class CardComponentWidget extends StatefulWidget {
  const CardComponentWidget({
    super.key,
    required this.name,
    required this.distance,
    required this.animalType,
    required this.image,
    bool? favorite,
  }) : this.favorite = favorite ?? false;

  final String? name;
  final double? distance;
  final String? animalType;
  final String? image;
  final bool favorite;

  @override
  State<CardComponentWidget> createState() => _CardComponentWidgetState();
}

class _CardComponentWidgetState extends State<CardComponentWidget> {
  late CardComponentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CardComponentModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130.0,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            alignment: AlignmentDirectional(1.0, -1.0),
            children: [
              Padding(
                padding: EdgeInsets.all(4.0),
                child: FlutterFlowIconButton(
                  borderRadius: 50.0,
                  buttonSize: 30.0,
                  fillColor: FlutterFlowTheme.of(context).primary,
                  icon: Icon(
                    Icons.favorite,
                    color: widget!.favorite
                        ? FlutterFlowTheme.of(context).error
                        : FlutterFlowTheme.of(context).info,
                    size: 14.0,
                  ),
                  onPressed: () {
                    print('IconButton pressed ...');
                  },
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  widget!.image!,
                  width: double.infinity,
                  height: 120.0,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
          Text(
            valueOrDefault<String>(
              widget!.name,
              '--',
            ),
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w600,
                ),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(
                Icons.location_on_sharp,
                color: FlutterFlowTheme.of(context).primary,
                size: 12.0,
              ),
              Expanded(
                child: RichText(
                  textScaler: MediaQuery.of(context).textScaler,
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: formatNumber(
                          widget!.distance,
                          formatType: FormatType.decimal,
                          decimalType: DecimalType.automatic,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                      ),
                      TextSpan(
                        text: ' km . ',
                        style: TextStyle(),
                      ),
                      TextSpan(
                        text: valueOrDefault<String>(
                          widget!.animalType,
                          '---',
                        ),
                        style: TextStyle(),
                      )
                    ],
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Inter',
                          letterSpacing: 0.0,
                        ),
                  ),
                  maxLines: 1,
                ),
              ),
            ],
          ),
        ].divide(SizedBox(height: 4.0)),
      ),
    );
  }
}
