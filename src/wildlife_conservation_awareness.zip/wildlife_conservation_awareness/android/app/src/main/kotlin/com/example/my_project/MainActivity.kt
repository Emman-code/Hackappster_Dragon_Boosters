package com.mycompany.wildlifeconservationawareness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
